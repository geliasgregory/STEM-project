# Architectuur van de MVP

- Next.js App Router voor pagina's en API-routes
- React voor de gebruikersinterface
- TypeScript voor types en onderhoudbaarheid
- JSON-bestand als tijdelijke lokale opslag
- Optionele OpenAI Responses API voor coachfeedback
- Lokale coach als kosteloze fallback

## Productiegrens
JSON-opslag is niet geschikt voor meerdere servers of gevoelige leerlinggegevens. Voor pilots met echte gebruikers moeten authenticatie, PostgreSQL, objectopslag, encryptie, rechten, logging en GDPR-processen worden toegevoegd.
