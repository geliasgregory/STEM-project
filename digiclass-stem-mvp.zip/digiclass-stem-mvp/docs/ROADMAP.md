# Organische roadmap

## Nu: demo-MVP
Bewijzen dat leerlingen zelfstandig door een technisch project kunnen bewegen en dat de verzamelde informatie bruikbaar wordt als showcase en pitch.

## Eerst valideren
1. Begrijpen leerlingen de zestien stappen zonder lange uitleg?
2. Bespaart de coach werkelijk tijd voor de leerkracht?
3. Welke feedback moet altijd door een mens bevestigd worden?
4. Vinden bedrijven de showcases bruikbaar om talent en projecten te volgen?
5. Wie wil betalen, waarvoor en vanaf welk moment?

## Waarschijnlijke volgende bouwblokken
- Accounts, rollen en schoolomgevingen
- PostgreSQL en veilige bestandsopslag
- Leerkrachtdashboard met goedkeuringsworkflow
- Rubrics, leerdoelen en versiegeschiedenis
- Foto-, video- en documentuploads
- Bedrijvenchallenges en mentorschap
- Toestemming, privacy, auditlog en bewaartermijnen

Deze volgorde is bewust niet definitief. Nieuwe functies worden eerst als feedback-item geregistreerd en pas gebouwd wanneer het probleem voldoende bewezen is.
