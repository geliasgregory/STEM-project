import OpenAI from "openai";
import type { Project, Step } from "./types";

function localCoach(step: Step) {
  const text = step.content.trim();
  if (text.length < 80) return "Je basis is nog te kort. Voeg minstens één concrete gebruiker, één meetbaar gegeven en één technische keuze met motivatie toe.";
  const hasNumber = /\d/.test(text);
  const hasReason = /omdat|waardoor|zodat|daarom/i.test(text);
  const suggestions = [];
  if (!hasNumber) suggestions.push("maak minstens één eis of resultaat meetbaar");
  if (!hasReason) suggestions.push("motiveer waarom je voor deze aanpak kiest");
  suggestions.push("benoem het grootste risico en hoe je dat gaat testen");
  return `Sterke start: je beschrijving bevat voldoende inhoud. Volgende verbetering: ${suggestions.join(", ")}. Sluit af met één concrete volgende actie.`;
}

export async function coach(project: Project, step: Step) {
  if (!process.env.OPENAI_API_KEY) return localCoach(step);
  const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
  const response = await client.responses.create({
    model: process.env.OPENAI_MODEL || "gpt-5-mini",
    instructions: "Je bent een kritische STEM-projectcoach voor 15- tot 18-jarigen. Geef geen volledige oplossing. Stel gerichte verbeteringen voor in helder Nederlands. Maximaal 130 woorden.",
    input: `Project: ${project.title}\nProbleem: ${project.problem}\nStap: ${step.title}\nOpdracht: ${step.prompt}\nAntwoord leerling: ${step.content}`
  });
  return response.output_text;
}

export function generateOutputs(project: Project) {
  const value = (id: string) => project.steps.find((s) => s.id === id)?.content || "Nog niet ingevuld";
  const productPage = `# ${project.title}\n\n## Het probleem\n${value("probleem")}\n\n## Onze oplossing\n${value("concept")}\n\n## Voor wie?\n${value("doelgroep")}\n\n## Belangrijkste voordelen en eisen\n${value("eisen")}\n\n## Getest in de praktijk\n${value("testen")}\n\n## Kostprijs en markt\n${value("kostprijs")}\n\n## Duurzaamheid\n${value("impact")}\n\nOntwikkeld door ${project.team} — ${project.school}.`;
  const pitch = `Wij zijn ${project.team} en wij ontwikkelden ${project.title}.\n\nHet probleem: ${value("probleem")}\n\nOnze oplossing: ${value("concept")}\n\nOnze doelgroep: ${value("doelgroep")}\n\nHet bewijs: ${value("testen")}\n\nHet verdienmodel: ${value("kostprijs")}\n\nOnze vraag aan de jury: help ons met expertise, testmogelijkheden en een eerste praktijkpartner om dit concept verder te valideren.`;
  return { productPage, pitch };
}
