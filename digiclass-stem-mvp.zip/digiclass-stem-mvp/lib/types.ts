export type Step = {
  id: string;
  title: string;
  prompt: string;
  content: string;
  feedback: string;
  completed: boolean;
};

export type Project = {
  id: string;
  title: string;
  team: string;
  school: string;
  problem: string;
  createdAt: string;
  updatedAt: string;
  steps: Step[];
  productPage?: string;
  pitch?: string;
};
