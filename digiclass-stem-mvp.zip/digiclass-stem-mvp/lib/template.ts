import type { Step } from "./types";

const definitions = [
  ["probleem", "Probleem en behoefte", "Welk concreet probleem lossen jullie op, voor wie en waarom is dit belangrijk?"],
  ["doelgroep", "Doelgroep en gebruikers", "Beschrijf de primaire gebruiker en de omstandigheden waarin het product gebruikt wordt."],
  ["onderzoek", "Onderzoek en bestaande oplossingen", "Welke oplossingen bestaan al? Wat werkt goed en waar liggen kansen tot verbetering?"],
  ["eisen", "Functionele eisen", "Noteer meetbare eisen: prestaties, afmetingen, veiligheid, energie, kostprijs en gebruiksgemak."],
  ["concept", "Technisch concept", "Leg de gekozen werking uit. Benoem onderdelen, energiestromen, signalen en belangrijke ontwerpkeuzes."],
  ["planning", "Planning en taakverdeling", "Verdeel het project in stappen, wijs eigenaars toe en schat de benodigde tijd."],
  ["bom", "Materiaallijst en ontwikkelingskosten", "Som alle onderdelen, aantallen, leveranciers, prijzen en ontwikkelingskosten op."],
  ["prototype", "Prototype bouwen", "Beschrijf hoe het prototype wordt gebouwd, welke gereedschappen nodig zijn en welke veiligheidsregels gelden."],
  ["testen", "Testplan en resultaten", "Welke tests bewijzen dat de functionele eisen gehaald worden? Noteer methode, meetwaarden en resultaat."],
  ["verbeteren", "Verbeteringen", "Welke fouten of beperkingen zijn gevonden en welke aanpassing heeft de grootste impact?"],
  ["kostprijs", "Kostprijs, verkoopprijs en break-even", "Bereken materiaal, arbeid, overhead, marge, verkoopprijs en break-evenaantal."],
  ["impact", "Duurzaamheid en maatschappelijke impact", "Analyseer levensduur, herstelbaarheid, materiaalgebruik, energie en mogelijke neveneffecten."],
  ["documentatie", "Technische documentatie", "Maak een duidelijke gebruikers-, montage- of onderhoudsinstructie."],
  ["productpagina", "Productverhaal", "Schrijf een heldere uitleg van probleem, oplossing, voordelen, bewijs en doelgroep."],
  ["pitch", "Pitchvoorbereiding", "Formuleer probleem, oplossing, markt, bewijs, verdienmodel en concrete vraag aan de jury."],
  ["reflectie", "Reflectie", "Wat hebben jullie geleerd, wat zouden jullie anders doen en welke competenties zijn zichtbaar gegroeid?"]
];

export function createSteps(): Step[] {
  return definitions.map(([id, title, prompt]) => ({ id, title, prompt, content: "", feedback: "", completed: false }));
}
