import { promises as fs } from "fs";
import path from "path";
import type { Project } from "./types";

const file = path.join(process.cwd(), "data", "store.json");
const seedFile = path.join(process.cwd(), "data", "seed.json");

async function ensureStore() {
  try { await fs.access(file); }
  catch { await fs.copyFile(seedFile, file); }
}

export async function readProjects(): Promise<Project[]> {
  await ensureStore();
  return JSON.parse(await fs.readFile(file, "utf8"));
}

export async function writeProjects(projects: Project[]) {
  await fs.mkdir(path.dirname(file), { recursive: true });
  await fs.writeFile(file, JSON.stringify(projects, null, 2));
}

export async function getProject(id: string) {
  return (await readProjects()).find((p) => p.id === id);
}
