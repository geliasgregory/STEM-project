"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
export default function CreateProject(){
 const router=useRouter(); const [busy,setBusy]=useState(false);
 async function submit(formData:FormData){setBusy(true);const res=await fetch("/api/projects",{method:"POST",body:JSON.stringify(Object.fromEntries(formData)),headers:{"Content-Type":"application/json"}});const p=await res.json();router.push(`/project/${p.id}`)}
 return <form action={submit}><label>Projectnaam</label><input name="title" required placeholder="Slimme energieverdeler"/><label>Team</label><input name="team" required placeholder="Team Volt"/><label>School</label><input name="school" required placeholder="STEM-school"/><label>Probleem</label><textarea name="problem" required placeholder="Welk probleem willen jullie oplossen?"/><button className="btn" disabled={busy}>{busy?"Aanmaken...":"Start nieuw project"}</button></form>
}
