import { notFound } from "next/navigation";import ProjectWorkspace from "@/components/ProjectWorkspace";import { getProject } from "@/lib/store";
export const dynamic="force-dynamic";
export default async function Page({params}:{params:Promise<{id:string}>}){const {id}=await params;const project=await getProject(id);if(!project)notFound();return <main className="wrap"><ProjectWorkspace initial={project}/></main>}
