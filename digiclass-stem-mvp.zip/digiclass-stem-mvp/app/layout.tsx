import "./globals.css";
export const metadata = { title: "DigiClass STEM", description: "AI-ondersteunde STEM-projectbegeleiding" };
export default function RootLayout({ children }: { children: React.ReactNode }) { return <html lang="nl"><body>{children}</body></html>; }
